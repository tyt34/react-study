import React from "react";
import "./{{kebabCase}}.scss";

const {{pascalCase}} = () => {
  return (
    <>
      <section className="{{kebabCase}}">{{pascalCase}}</section>
    </>
  );
};

export default {{pascalCase}};
