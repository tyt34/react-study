import React, { FC } from "react";
import "./{{kebabCase}}.scss";

type Props = {
  text: string
};

const {{pascalCase}}: FC<Props> = ({text}) => {
  return (
    <>
      <section className="{{kebabCase}}">{{pascalCase}}</section>
    </>
  );
};

export default {{pascalCase}};
