import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
//import { store } from "../../store/store";

export type Props = {
  abc: {
    text: string;
  };
};

const initialState: Props = {
  abc: {
    text: "hello",
  },
};

export const {{kebabCase}}Slice = createSlice({
  name: "data",
  initialState,
  reducers: {
    setAbcText: (state, action: PayloadAction<string>) => {
      state.abc.text = action.payload;
    },
  },
});

export const { setAbcText } = {{kebabCase}}Slice.actions;
export type {{kebabCase}}State = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
